#!/usr/bin/perl

# g4rep.pl ver. 1.0.0
# Copyright (C) 2014 Yuki Kato
# This script is used to detect non-overlapping G-quadruplex (G4) sequences in a specified genomic sequence using pattern matching with regular expression.
# Usage: Type "./g4rep.pl" in your terminal.

use strict;
use warnings;
use Getopt::Long qw(:config no_ignore_case);

my %opt = (gmin=>3, Gmax=>5, lmin=>1, Lmax=>7, help => 0);
GetOptions(\%opt, qw(gmin=i Gmax=i lmin=i Lmax=i help)) or exit;

# Argument check
if (!exists $ARGV[0] || $opt{help} == 1) {
    print "g4rep.pl ver. 1.0.0\n\n";
    print "This script is used to detect non-overlapping G-quadruplex (G4) sequences in a specified genomic sequence using pattern matching with regular expression.\n\n";
    print "Usage: ./g4rep.pl [OPTION] [FILE]\n\n";
    print "[FILE]\n";
    print " Path to the file for the genomic sequence in gzipped FASTA format\n\n";
    print "[OPTION]\n";
    print " -g, --gmin INT  The minimum length of G-runs\n";
    print "                  (default INT = 3)\n";
    print " -G, --Gmax INT  The maximum length of G-runs\n";
    print "                  (default INT = 5)\n";
    print " -l, --lmin INT  The minimum length of loops\n";
    print "                  (default INT = 1)\n";
    print " -L, --Lmax INT  The maximum length of loops\n";
    print "                  (default INT = 7)\n";
    print " -h, --help      Show this message\n\n";
    exit;
}

# Read the gzipped FASTA file
my @fasta = `gunzip -c $ARGV[0]`;
my $id = "";
my $seq = "";

foreach my $item (@fasta) {
    if ($item =~ /^>(\w+)/) {$id = $1;}

    elsif ($item =~ /^(\w+)/) {
	$seq = $seq.$1;
    }
}

# Find and print non-overlapping G4 sequences
while ($seq =~ /(G{$opt{gmin},$opt{Gmax}}[ACGTacgt]{$opt{lmin},$opt{Lmax}}G{$opt{gmin},$opt{Gmax}}[ACGTacgt]{$opt{lmin},$opt{Lmax}}G{$opt{gmin},$opt{Gmax}}[ACGTacgt]{$opt{lmin},$opt{Lmax}}G{$opt{gmin},$opt{Gmax}})/go) {
    print "$1\n";
}
