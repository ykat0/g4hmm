//////////////////////////////
//  PLATEANUS
//  author: YANO Masato
//////////////////////////////
 This program "platanus" run out k-fold cross validation (Baum-Welch algorithm for lerning and Viterbi algortihm for evaluation). The sources are available, which are ./src/*.cpp and ./src/header/*.h.

A) HOW TO USE
  [1]  $ gmake
        compile the program.
        clean command is available. -> `$ gmake clean'
  [2]  $ ./platanus -i MODEL -s SEQUENCE
        sample: $./platanus -i model1 -s g4
        [OPTION]
          -i MODEL       assign a model to use.
          -s SEQUENCE    assign a source.
          -o OUTPUT      name output-file. (optional)
          -k K           change k, default is 10. (optional)

B) HOW TO READ RESULTS
    The program outputs `*.#' and `*.path#', where * is the name of the source and # is the count of iteration (0-k).
  [i]   *.#
         this file is new HMM specification in #th iteration.
  [ii]  *.path#
         this file is path made by Viterbi algorithm in #th iteration.
         * indicate G-run.
         sample) GGGTTAGGGTTAGGGTTAGGG
                 ***   ***   ***   ***

C) HOW TO MAKE HMM
#State
here, put on number of states.
#Prob.
destination1 probability1 dest2 prob2 ... : probability of A, C, G and T
...
