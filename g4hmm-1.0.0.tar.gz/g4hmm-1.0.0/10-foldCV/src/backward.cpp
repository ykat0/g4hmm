#ifndef INCLUDED_BACKWARD
#include "header/backward.h"
#endif // INCLUDED_BACKWARD

using namespace std;
using namespace myhmm;
using namespace myrecurrence;

namespace mybackward {
  //// class Backward
  double Backward::Recurse(const int &k, const int &i) {
    // Terminal condition 1 (arrive to "begin")
    if (IsTypeOfState(k, end)) {
      //cout << k << ", " << i << endl;
      double p_sum = IsOutput(i, 0.0, 1.0);
      dptable_.push_back(DPCell(p_sum, k, i, 0));
      return p_sum;
    } else {
      double p_sum = 0;
      // Terminal condition 2 (finish to read)
      if (IsOutput(i, true, false) || IsTypeOfState(k, begin)) {
        int refer_cell;
        for (int l = 0; l < GetNumberOfState(); l++) {
          if (GetTransitionProbability(k, l) > 0.0) {
            refer_cell= ReferDPTable(l, i + 1);
            int alphabet = GetIdOfAlphabet(target_->substr(i + 1, 1));
            p_sum += (IsTypeOfState(l, end) ?
                      1.0 :
                      GetOutputProbability(l, alphabet)) *
                     GetTransitionProbability(k, l) *
                     ((unsigned)refer_cell < dptable_.size() ?
                      dptable_[refer_cell].p :
                      Recurse(l, i + 1));
          }
        }
        dptable_.push_back(DPCell(p_sum, k, i, 0));
        return p_sum;
      } else {
        return 0;
      }
    }
  }
  double Backward::Run(const string &input_sequence) {
    return Run(input_sequence, 0, -1);
  }
  double Backward::Run(const string &input_sequence,
                       const int &k, const int &i) {
    result_flag_ = false;
    dptable_.clear();
    target_ = &input_sequence;
    if (IsTypeOfState(k, end)) {
      return 1.0;
    } else {
      result_flag_ = true;
      return Recurse(k, i);
    }
  }
  void Backward::ShowResult() {
    cout << " RESULT:" << endl;
    if(!result_flag_) {
      cout << "  NO DATA. You MUST do run() first." << endl;
    } else {
      for (unsigned int i = 0; i < dptable_.size(); i++)
        cout << dptable_[i].p << " ";
      cout << "  DP-table size: " << dptable_.size() << endl;
    }
  }
  void Backward::Clear() {
    result_flag_ = false;
    dptable_.clear();
  }
};
