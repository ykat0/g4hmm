// To run backward algorithm
#ifndef INCLUDED_BACKWARD
#define INCLUDED_BACKWARD

#ifndef INCLUDED_RECURRENCE
#include "recurrence.h"
#endif //INCLUDED_RECURRENCE

namespace mybackward {
  class Backward : public myrecurrence::Recurrence {
   public:
    Backward() : Recurrence() {};
    ~Backward() {};
    double Run(const std::string &input_sequence);
    double Run(const std::string &input_sequence,
               const int &k, const int &i);
    void ShowResult();
    void Clear();
   private:
    double Recurse(const int &k, const int &i);
  };
};

#endif // INCLUDED_BACKWARD
