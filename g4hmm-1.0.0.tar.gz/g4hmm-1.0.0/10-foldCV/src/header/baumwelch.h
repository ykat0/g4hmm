// To run Baum-Welch algorithm
#ifndef INCLUDED_BAUMWELCH
#define INCLUDED_BAUMWELCH

#ifndef INCLUDED_HEADER
#include "header.h"
#endif //INCLUDED_HEADER
#ifndef INCLUDED_HMM
#include "hmm.h"
#endif // INCLUDED_HMM
#ifndef INCLUDED_FORWARD
#include "forward.h"
#endif // INCLUDED_FORWARD
#ifndef INCLUDED_BACKWARD
#include "backward.h"
#endif // INCLUDED_BACKWARD

namespace mybaumwelch {
  const double EFFECTIVE_DIFFERENCE = 0.1;
  const int LOOP_BOUND = 50;
  struct Likelihood {
    double older;
    double newer;
  };
  class BaumWelch : public myhmm::HMM {
   public:
    BaumWelch() {};
    ~BaumWelch() {};
    void Renew(const std::vector<std::string> &sequence_set);
    void Reset();
   private:
    std::vector<double> expect_transition_;
    std::vector<double> expect_output_;
    std::vector<double> renew_transition_probability_;
    std::vector<double> renew_output_probability_;
    std::vector<std::string> sequences_;
    myforward::Forward f_;
    mybackward::Backward b_;
    static Likelihood likelihood_;
    void RenewBody(double *likelihood);
    double ComputeLikelihood();
    double ComputeExpectTransition(const int &k, const int &l);
    double ComputeExpectOutput(const int &k, const int &b);
    int SetSequenceSet(const std::vector<std::string> &set);
  };
};

#endif // INCLUDED_BAUMWELCH
