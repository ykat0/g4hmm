#ifndef INCLUDED_OPERATION
#define INCLUDED_OPERATION

#ifndef INCLUDED_HEADER
#include "header.h"
#endif //INCLUDED_HEADER
#ifndef INCLUDED_HMM
#include "hmm.h"
#endif // INCLUDED_HMM
#ifndef INCLUDED_VITERBI
#include "viterbi.h"
#endif // INCLUDED_VITERBI
#ifndef INCLUDED_FORWARD
#include "forward.h"
#endif // INCLUDED_FORWARD
#ifndef INCLUDED_BACKWARD
#include "backward.h"
#endif // INCLUDED_BACKWARD
#ifndef INCLUDED_BAUMWELCH
#include "baumwelch.h"
#endif // INCLUDED_BAUMWELCH


namespace myoperation {
  struct Algorithms {
     myviterbi::Viterbi vi;
     myforward::Forward fo;
     mybackward::Backward ba;
     mybaumwelch::BaumWelch bw;
  };
  class Operation {
   public:
	   Operation() : cout_flag_(false) {};
     int SetHMM(const std::string &define_filename);
     int SetSequence(const std::string &source_filename);
     void MakePaths(const int &k_size, const std::string &name);
     int DrawPath(const std::vector<std::string> &set);
     void SavePaths(const std::string &save_filename,
                    const std::vector<std::string> &set);
     void RenewHMM(const std::vector<std::string> &set);
     void RenewHMM(const std::string outputname);
     void SaveHMM(const std::string &save_filename);
     void FlagCout(const bool &flag);
     bool FlagChck();
     Algorithms algorithms_;
   private:
     std::ifstream hmm_file_;
     std::vector<std::string> sequence_set_;
     std::vector<std::string> path_set_;
     std::vector<std::string> learning_set_;
     std::vector<std::string> test_set_;
     bool cout_flag_;
     myhmm::HMM hmm_;
  };
};

#endif
