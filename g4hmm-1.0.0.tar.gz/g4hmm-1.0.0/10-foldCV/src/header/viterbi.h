// To run viterbi algorithm
#ifndef INCLUDED_VITERBI
#define INCLUDED_VITERBI

#ifndef INCLUDED_RECURRENCE
#include "recurrence.h"
#endif //INCLUDED_RECURRENCE

namespace myviterbi {
  class Viterbi : private myrecurrence::Recurrence {
   public:
    Viterbi() : Recurrence() {};
    ~Viterbi() {};
    double Run(const std::string &input_sequence);
    double Run(const std::string &input_sequence,
               const int &k, const int &i);
    void ShowResult();
    std::string ReturnResult();
    void Clear();
   private:
    double Recurse(const int &k, const int &i);
  };
};

#endif // INCLUDED_VITERBI
