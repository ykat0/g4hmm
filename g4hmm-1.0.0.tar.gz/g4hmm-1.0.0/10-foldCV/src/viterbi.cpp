#ifndef INCLUDED_VITERBI
#include "header/viterbi.h"
#endif // INCLUDED_VITERBI

using namespace std;
using namespace myhmm;
using namespace myrecurrence;

namespace myviterbi {
  //// class Viterbi
  double Viterbi::Recurse(const int &k, const int &i) {
    // Terminal condition 1 (arrive to "begin")
    if (IsTypeOfState(k, begin)) {
      double p_max = IsOutput(i, -INF, 0.0);
      dptable_.push_back(DPCell(p_max, k, i, -1));
      return p_max;
    } else {
      double p, p_max = -INF - 1, output_probability;
      int l_max = 0;
      // Terminal condition 2 (finish to read)
      if (IsOutput(i, true, false)) { // not finish
        output_probability =
          GetOutputProbability(k, GetIdOfAlphabet(target_->substr(i, 1)));
      } else { // finish
        output_probability = (IsTypeOfState(k, end) ? 1.0 : 0.0);
      }
      if (output_probability > 0.0) {
        int refer_cell;
        for (int l = 0; l < GetNumberOfState(); l++) {
          if (GetTransitionProbability(l, k) > 0.0) {
            refer_cell = ReferDPTable(l, i - 1);
            p = log10(GetTransitionProbability(l, k)) +
                ((unsigned)refer_cell < dptable_.size() ?
                  dptable_[refer_cell].p :
                  Recurse(l, i - 1));
          } else {
            p = -INF;
          }
          if (p > p_max) {
            p_max = p;
            l_max = l;
          }
        }
        p_max += log10(output_probability);
      } else {
        p_max = -INF;
      }
      dptable_.push_back(DPCell(p_max, k, i, l_max));
      return p_max;
    }
  }
  double Viterbi::Run(const string &input_sequence) {
    return Run(input_sequence, 
               GetNumberOfState() - 1,
               input_sequence.length());
  }
  double Viterbi::Run(const std::string &input_sequence,
                      const int &k, const int &i) {
    result_flag_ = false;
    dptable_.clear();
    target_ = &input_sequence;
    if (IsTypeOfState(k, begin)) {
      return 1;
    } else {
      result_flag_ = true;
      return Recurse(k, i);
    }
  }
  // Show result
  void Viterbi::ShowResult() {
    if (!result_flag_) {
      cout << "  NO DATA. You MUST do run() first." << endl;
    } else {
      vector<DPCell>::iterator loop;
      vector<DPCell>::iterator finder = dptable_.end();
      double max_probability = -INF - 1;
      for (loop = dptable_.begin(); loop < dptable_.end(); loop++) {
        if (IsTypeOfState(loop->k, end) && loop->p > max_probability) {
          finder = loop;
          max_probability = loop->p;
        }
      }
      cout << "vi: Prob(Log10) = " << max_probability << endl;
      cout << "      Prob(Raw) = " << pow(10, max_probability) << endl;
      if (max_probability < -INF) return;
      int kk = finder->l, ii = finder->i - 1;
      cout << *target_ << endl;
      bool loop_enable = true;
      string result_string;
      do {
        loop_enable = false;
        for (loop = dptable_.begin(); loop < dptable_.end(); loop++) {
          if (loop->k == kk && loop->i == ii) {
            if (IsTypeOfState(loop->k, end, begin))
              break;
            if (GetOutputProbability(loop->k, 0) == 0.0 &&
                GetOutputProbability(loop->k, 1) == 0.0 &&
                GetOutputProbability(loop->k, 2) == 1.0 &&
                GetOutputProbability(loop->k, 3) == 0.0) {
              result_string += "*";
            } else {
              result_string += ".";
            }
            kk = loop->l;
            ii--;
            loop_enable = true;
          }
        }
      } while(loop_enable);
      for (int i = result_string.size() - 1; i >= 0; i--)
        cout << result_string.substr(i, 1);
      cout << endl;
      cout << "  DP-table size: " << dptable_.size() << endl;
    }
  }
  string Viterbi::ReturnResult() {
    string return_string;
    if (!result_flag_) {
      return_string = "NO DATA. You MUST do run() first.";
    } else {
      vector<DPCell>::iterator loop;
      vector<DPCell>::iterator finder = dptable_.end();
      double max_probability = -INF - 1;
      for (loop = dptable_.begin(); loop < dptable_.end(); loop++) {
        if (IsTypeOfState(loop->k, end) && loop->p > max_probability) {
          finder = loop;
          max_probability = loop->p;
        }
      }
      if (max_probability < -INF) return "NO PATH";
      int kk = finder->l, ii = finder->i - 1;
      bool loop_enable = true;
      string result_string;
      do {
        loop_enable = false;
        for (loop = dptable_.begin(); loop < dptable_.end(); loop++) {
          if (loop->k == kk && loop->i == ii) {
            if (IsTypeOfState(loop->k, end, begin))
              break;
            if (GetOutputProbability(loop->k, 0) == 0.0 &&
                GetOutputProbability(loop->k, 1) == 0.0 &&
                GetOutputProbability(loop->k, 2) == 1.0 &&
                GetOutputProbability(loop->k, 3) == 0.0) {
              result_string += "*";
            } else {
              result_string += ".";
            }
            kk = loop->l;
            ii--;
            loop_enable = true;
          }
        }
      } while(loop_enable);
      for (int i = result_string.size() - 1; i >= 0; i--)
        return_string += result_string.substr(i, 1);
    }
    return return_string;
  }
  void Viterbi::Clear() {
    result_flag_ = false;
    dptable_.clear();
  }
};
