// author: YANO Masato
// 10-fold cross validation program
//            for "Using hidden Markov models to investigate
//                 G-quadruplex motifs in genomic sequences."

#ifndef INCLUDED_OPERATION
#include "header/operation.h"
#endif // INCLUDED_OPERATION
#ifndef _UNISTD_H_
#include <unistd.h>
#endif // _UNISTD_H_

using namespace std;
using namespace myoperation;
using namespace mycommands;

void help() {
  cout << "Usage: ./platanus -i HMM FILE -s SEQUENCES [OPTION]" << endl;
  cout << "-i and -s options are needed." << endl;
  cout << "[OPTION]" << endl;
  cout << "  -o NAME   name output file," << endl;
  cout << "            for example \"model.n\" as n-th renewed model spec." << endl;
  cout << "            and \"model.pathn\" as n-th path by viterbi alg." << endl;
  cout << "  -k K      change to any k-fold cross validation." << endl;
  cout << "  -f        display comments." << endl;
}

int main(int argc, char *argv[]) {
  Operation operation;
  const string usage = "Usage: ./platanus -i HMM -s SEQUENCE\n       -o option can name output file.\n       -k option let you change k to any k.";
  int k = 10; // if you want to use any k, change here;
  // Read arguments.
  int arg_case;
  string hmm_file = "dammy";
  string output = "output";
  string seq_file = "dammy";
  string tmp;
  while ((arg_case = getopt(argc, argv, "i:o:s:k:fh")) != -1) {
    switch (arg_case) {
    case 'i':
      hmm_file = optarg;
      break;
    case 'o':
      output = optarg;
      break;
    case 's':
      seq_file = optarg;
      break;
    case 'k':
      tmp = optarg;
      k = GetDigit<int>(tmp);
      break;
    case 'f':
      operation.FlagCout(true);
      break;
    case 'h':
      help();
      return 0;
      break;
    }
  }
  // Operation
  if (operation.SetSequence(seq_file) > 0) {
    if (operation.SetHMM(hmm_file) > 0) {
      if (operation.FlagChck())
        cout << "##" << k << "-fold cross validation: do" << endl;
      operation.MakePaths(k, output);
      operation.RenewHMM(output);
    } else {
      cout << usage << endl;
      cout << "-i option may be fault: " << hmm_file << "." << endl;
    }
  } else {
    cout << usage << endl;
    cout << "-s option may be fault: " << seq_file << "." << endl;
  }
  cout << "Finish!" << endl;
  return 0;
}
