#ifndef INCLUDED_OPERATION
#include "header/operation.h"
#endif // INCLUDED_OPERATION

using namespace std;
using namespace mycommands;

namespace myoperation {
  // Read HMM define and set up HMM.
  int Operation::SetHMM(const string &hmm_file) {
    ifstream ifs;
    ifs.open(hmm_file.data(), ios::in);
    if (ifs == NULL) {
      return 0;
    } else {
      hmm_.Setup(&ifs);
      hmm_.WriteHMMSpec("init");
      ifs.close();
      return hmm_.GetNumberOfState();
    }
  }
  // Read sequences.
  int Operation::SetSequence(const string &sequences) {
    ifstream ifs;
    ifs.open(sequences.data(), ios::in);
    if (!sequence_set_.empty())
      return sequence_set_.size();
    if (ifs == NULL) {
      return 0;
    } else {
      string temp;
      while(true) {
        getline(ifs, temp);
        if (temp.empty()) break;
        sequence_set_.push_back(temp);
      }
      ifs.close();
      return sequence_set_.size();
    }
  }
  // Draw path by viterbi arg.
  int Operation::DrawPath(const vector<string> &set) {
    for (unsigned int i = 0; i < set.size(); i++) {
      algorithms_.vi.Run(set.at(i));
      path_set_.push_back(algorithms_.vi.ReturnResult());
    }
    return path_set_.size();
  }
  // Save path (by viterbi) to output (-o option)
  void Operation::SavePaths(const string &output,
                            const vector<string> &set) {
    ofstream ofs;
    ofs.open(output.data(), ios::out);
    for (unsigned int i = 0; i < path_set_.size(); i++) {
      ofs << set.at(i) << endl;
      ofs << path_set_.at(i) << endl;
    }
    ofs.close();
    path_set_.clear();
  }
  // Renew HMM define
  void Operation::RenewHMM(const vector<string> &set) {
    algorithms_.bw.Reset();
    algorithms_.bw.Renew(set);
  }
  void Operation::RenewHMM(const string outputname) {
    algorithms_.bw.Reset();
    algorithms_.bw.Renew(sequence_set_);
    SaveHMM(outputname);
  }
  // Save new HMM define
  void Operation::SaveHMM(const string &output) {
    hmm_.WriteHMMSpec(output);
  }
  // Learning (Baum-Welch alg.)
  void Operation::MakePaths(const int &k_size, const string &name) {
    int testset_size = sequence_set_.size() / k_size;
    int testset_start, testset_end;
    for (int i = 0; i < k_size; i++) {
      //SetHMM("learned" + GetString(i));
      SetHMM("init");
      testset_start = i * testset_size;
      testset_end = (i + 1) * testset_size;
      if (cout_flag_) cout << "[" << testset_start << ", " << testset_end - 1 << "]" << endl;
      for (int j = 0; (unsigned)j < sequence_set_.size(); j++) {
        if (j >= testset_start && j < testset_end) {
          test_set_.push_back(sequence_set_.at(j));
        } else {
          learning_set_.push_back(sequence_set_.at(j));
        }
      }
      RenewHMM(learning_set_);
      SaveHMM(name + "." + GetString(i));
      DrawPath(test_set_);
      SavePaths(name + ".path" + GetString(i), test_set_);
      learning_set_.clear();
      test_set_.clear();
    }
  }
  // Flag opt.
  void Operation::FlagCout(const bool &flag) {
    cout_flag_ = flag;
  }
  bool Operation::FlagChck() {
    return cout_flag_;
  }
};
