#ifndef INCLUDED_BAUMWELCH
#include "header/baumwelch.h"
#endif // INCLUDED_BAUMWELCH

using namespace std;
using namespace myhmm;

namespace mybaumwelch {
  Likelihood BaumWelch::likelihood_ = {-15, -10};
  //// class BaumWelch
  void BaumWelch::Reset() {
    likelihood_.older = -15;
    likelihood_.newer = -10;
    expect_transition_.clear();
    expect_output_.clear();
    renew_transition_probability_.clear();
    renew_output_probability_.clear();
    sequences_.clear();
  }
  void BaumWelch::Renew(const vector<string> &sequence_set) {
    if (sequences_.size() > 0) {
      sequences_.clear();
      SetSequenceSet(sequence_set);
      expect_transition_.clear();
      expect_output_.clear();
      renew_transition_probability_.clear();
      renew_output_probability_.clear();
    } else {
      SetSequenceSet(sequence_set);
    }
    int loop_counter = 0;
    if (likelihood_.newer - likelihood_.older > EFFECTIVE_DIFFERENCE) {
      RenewBody(&likelihood_.older);
      loop_counter++;
      SetTransitionProbability(renew_transition_probability_);
      SetOutputProbability(renew_output_probability_);
      RenewBody(&likelihood_.newer);
      loop_counter++;
      while (likelihood_.newer - likelihood_.older > EFFECTIVE_DIFFERENCE) {
        if (loop_counter >= LOOP_BOUND) {
          cout << "forced outage" << endl;
          break;
        }
        likelihood_.older = likelihood_.newer;
        SetTransitionProbability(renew_transition_probability_);
        SetOutputProbability(renew_output_probability_);
        RenewBody(&likelihood_.newer);
        loop_counter++;
      }
    } else {
      cout << "no need to renew." << endl;
    }
  }
  void BaumWelch::RenewBody(double *likelihood) {
    expect_transition_.clear();
    expect_output_.clear();
    renew_transition_probability_.clear();
    renew_output_probability_.clear();
    for (int k = 0; k < GetNumberOfState(); k++) {
      for (int l = 0; l < GetNumberOfState(); l++) {
        expect_transition_.push_back(ComputeExpectTransition(k, l));
      }
      for (int b = 0; b < GetAlphabetSize(); b++) {
        expect_output_.push_back(ComputeExpectOutput(k, b));
      }
    }
    for (int k = 0; k < GetNumberOfState(); k++) {
      double expect_transition_all_l = 0.0;
      double expect_output_all_b = 0.0;
      int position;
      for (int lp = 0; lp < GetNumberOfState(); lp++) {
        position = k * GetNumberOfState() + lp;
        expect_transition_all_l += expect_transition_[position];
      }
      for (int bp = 0; bp < GetAlphabetSize(); bp++) {
        position = k * GetAlphabetSize() + bp;
        expect_output_all_b += expect_output_[position];
      }
      for (int l = 0; l < GetNumberOfState(); l++) {
        position = k * GetNumberOfState() + l;
        if (expect_transition_all_l > 0.0) {
          renew_transition_probability_.push_back(
              expect_transition_[position] / expect_transition_all_l);
        } else {
          renew_transition_probability_.push_back(0);
        }
      }
      for (int b = 0; b < GetAlphabetSize(); b++) {
        position = k * GetAlphabetSize() + b;
        if (expect_output_all_b > 0.0) {
          renew_output_probability_.push_back(
              expect_output_[position] / expect_output_all_b);
        } else {
          renew_output_probability_.push_back(0);
        }
      }
    }
    *likelihood = ComputeLikelihood();
  }
  double BaumWelch::ComputeLikelihood() {
    double result = 0, output_probability;
    for(int k = 0; k < GetNumberOfState(); k++) {
      for(int b = 0; b < GetAlphabetSize(); b++) {
        output_probability =
            (IsTypeOfState(k, begin, end) ?
             1.0 :
             GetOutputProbability(k, b));
        if (output_probability > 0.0) {
          result += expect_output_[k * GetAlphabetSize() + b] *
                    log10(output_probability);
        } else {
          result += 0.0;
        }
      }
      for(int l = 0; l < GetNumberOfState(); l++) {
        if (GetTransitionProbability(k, l) > 0) {
          result += expect_transition_[k * GetNumberOfState() + l] *
                    std::log10(GetTransitionProbability(k, l));
        } else {
          result += 0.0;
        }
      }
    }
    return result;
  }
  double BaumWelch::ComputeExpectTransition(const int &k, const int &l) {
    double count_of_transition, probability_with_sequence;
    double result = 0.0;
    for (vector<string>::iterator it = sequences_.begin();
         it < sequences_.end(); 
         it++) {
      probability_with_sequence = f_.Run(*it);
      if (probability_with_sequence > 0.0) {
        count_of_transition = 0.0;
        int sequence_bit = -1;
        int alphabet_id = 0;
        do {
          if (GetTransitionProbability(k, l) > 0.0) {
            if ((unsigned)sequence_bit < it->length()) {
              alphabet_id = GetIdOfAlphabet(it->substr(sequence_bit + 1, 1));
            } else {
              alphabet_id = -1;
            }
            count_of_transition +=
              f_.Run(*it, k, sequence_bit) *
              GetTransitionProbability(k, l) *
              (IsTypeOfState(l, begin, end) ?
               1.0 :
               GetOutputProbability(l, alphabet_id)) *
              b_.Run(*it, l, sequence_bit + 1);
          }
          sequence_bit++;
        } while ((unsigned)sequence_bit <= it->length());
        result += (count_of_transition / probability_with_sequence);
      }
    }
    return result;
  }
  double BaumWelch::ComputeExpectOutput(const int &k, const int &b) {
    if (IsTypeOfState(k, begin, end)) {
        return 0.0;
    } else {
      double count_of_output, probability_with_sequence;
      double result = 0.0;
      for (vector<string>::iterator it = sequences_.begin();
           it < sequences_.end(); it++) {
        probability_with_sequence = f_.Run(*it);
        if (probability_with_sequence > 0.0) {
          count_of_output = 0.0;
          for (int i = 0; (unsigned)i < it->length(); i++) {
            if (GetIdOfAlphabet(it->substr(i, 1)) == b) {
              count_of_output +=
                f_.Run(*it, k, i) *
                b_.Run(*it, k, i);
            }
          }
          result += (count_of_output / probability_with_sequence);
        }
      }
      return result;
    }
  }
  int BaumWelch::SetSequenceSet(const vector<string> &set) {
    sequences_.clear();
    sequences_.reserve(set.size());
    copy(set.begin(), set.end(), back_inserter(sequences_));
    return sequences_.size();
  }
};
