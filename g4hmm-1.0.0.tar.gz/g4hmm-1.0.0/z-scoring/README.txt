//////////////////////////////
//  LILAC
//  author: YANO Masato
//////////////////////////////
 This program "lilac" gives Z-SCORE to G4 sequences by forward algorithm. The sources are available, which are ./src/*.cpp and ./src/header/*.h.

A) HOW TO USE
  [1]  $ make
        compile the program.
        clean command is available. -> `$ make clean'
  [2]  $ ./lilac -m MODEL -d DIR -l LIST
        sample: $./lilac -m model2 -d CHR -l chromosomelist
        [OPTION]
          -m MODEL       assign a model to use.
          -d DIR         assign a directory that has some sources.
                         DIR must have some files that has some G4 sequences.
          -l LIST        assign a list that has all name of source files in DIR.
          -r RESULT      name the directory for saving results. (optional)

B) HOW TO READ RESULTS
 The program outputs `_*', `indv_result' and `stat_result'
  [i]   _*
         * replaces the name of the source.
         In this file, there are 5 columns table, which are sequences, probabilities, log-likelihoods, log-likelihoods devided the length and log-odds.
  [ii]  indv_result
         This file have all sequences and their z-score as 4 column table, which are source names, seqeunces, z-scores and source number.
  [iii] stat_result
         This file have all sources and their mean, standard deviation and maximum value.

C) HOW TO MAKE HMM
#State
here, put on number of states.
#Prob.
destination1 probability1 dest2 prob2 ... : probability of A, C, G and T
...
