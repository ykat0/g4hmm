// author: YANO Masato
// z-scoring program
//            for "Using hidden Markov models to investigate
//                 G-quadruplex motifs in genomic sequences."

#ifndef INCLUDED_OPERATION
#include "header/operation.h"
#endif // INCLUDED_OPERATION
#ifndef _UNISTD_H_
#include <unistd.h>
#endif // _UNISTD_H

using namespace std;
using namespace myoperation;
using namespace mycommands;

void help() {
  cout << "Usage: ./lilac -m HMM -d SOURCE-DIRECTORY -l SOURCE-LIST [OPTION]" << endl;
  cout << "-m, -d and -l options are needed." << endl;
  cout << "[OPTION]" << endl;
  cout << "  -r NAME   name result directory." << endl;
}

int main(int argc, char *argv[]) {
  Operation operation;
  string usage = "Usage: ./lilac -m HMM -d SOURCE-DIRECTORY -l SOURCE-LIST\n       -r option assign the result directory.";
  // Read arguments
  int arg_case;
  string hmm_file = "dammyHMM";
  string list = "dammylist";
  string dir = "DAMMY";
  string result = "RESULT";
  while ((arg_case = getopt(argc, argv, "m:d:l:r:h")) != -1) {
    switch (arg_case) {
    case 'm':
      hmm_file = optarg;
      break;
    case 'd':
      dir = optarg;
      break;
    case 'l':
      list = optarg;
      break;
    case 'r':
      result = optarg;
      break;
    case 'h':
      help();
      return 0;
      break;
    }
  }
  // set up background probabilities
  operation.SetBackgroundProbabilities();
  // Open list file
  ifstream list_ifs;
  list_ifs.open(list.data(), ios::in);
  vector<string> list_vec;
  if (list_ifs != NULL) {
    string buff;
    for (getline(list_ifs, buff); !buff.empty(); getline(list_ifs, buff)) {
      list_vec.push_back(buff);
    }
  } else {
    cout << usage << endl;
    cout << "-l option may be fault: " << list << endl;
    return -1;
  }
  // operation
  if (operation.SetHMM(hmm_file) > 0) {
    mkdir(result.data(), 0766);
    // Crawling sources
    for (unsigned int s = 0; s < list_vec.size(); s++) {
      if (operation.SetSequence(dir + "/" + list_vec.at(s)) != 0)
        operation.MakeLogOddsTable(result, list_vec.at(s));
      else
        cout << dir << "/" << list_vec.at(s) << " does have no sequence." << endl;
    }
    operation.ComputeZ_Score(result);
  } else {
    cout << usage << endl;
    cout << "-m option may be fault: " << hmm_file << endl;
    return -1;
  }
  cout << "Finish!" << endl;
  return 0;
}
