#ifndef INCLUDED_OPERATION
#include "header/operation.h"
#endif // INCLUDED_OPERATION

using namespace std;

namespace myoperation {
  // Read HMM define and set up HMM.
  int Operation::SetHMM(const string &hmm_file) {
    ifstream ifs;
    ifs.open(hmm_file.data(), ios::in);
    if (ifs == NULL) {
      return 0;
    } else {
      hmm_.Setup(&ifs);
      hmm_.WriteHMMSpec("init");
      ifs.close();
      return hmm_.GetNumberOfState();
    }
  }
  // Read sequences.
  int Operation::SetSequence(const string &seq_file) {
    ifstream ifs;
    ifs.open(seq_file.data(), ios::in);
    if (ifs == NULL) {
      return 0;
    } else {
      string temp;
      sequence_set_.clear();
      while(true) {
        getline(ifs, temp);
        if (temp.empty()) break;
        sequence_set_.push_back(temp);
      }
      ifs.close();
      return sequence_set_.size();
    }
  }
  // Calculate log-odds
  double Operation::CalculateLogOdds(double probability, string sequence) {
    double background_probability = 1;
    map<string, int> nucleotide;
    for (unsigned int i = 0; i < sequence.length(); i++) {
      background_probability *=
        background_probabilities_[sequence.substr(i, 1)];
    }
    if (probability > 0) {
      return log10(probability / background_probability);
    } else {
      return 0;
    }
  }
  // Make log-odds table
  void Operation::MakeLogOddsTable(string dir, string src) {
    ofstream output;
    string filename = dir + "/_" + src;
    output.open(filename.data(), ios::out | ios::app);
    output << "sequence\tprobability\tLL\tLL/length\tlog-odds" << endl;
    for (unsigned int i = 0; i < sequence_set_.size(); i++) {
      string sequence = sequence_set_.at(i);
      double length = sequence.length();
      double probability = fo_.Run(sequence);
      // log-odds
      if (probability > 0) {
        double logodds = CalculateLogOdds(probability, sequence);
        sum_of_logodds_ += logodds;
        log_odds_table_.push_back(LogOddsTable(src, sequence, logodds));
        output << sequence_set_.at(i) << "\t"; // sequence
        output << probability << "\t"; // probability
        output << log10(probability) << "\t"; // LL
        output << log10(probability) / length << "\t"; // LL/length
        output << logodds << endl; // log-odds
      } else { // probability is zero.
        output << sequence_set_.at(i) << "\t"; // sequence
        output << "0\t"; // probability
        output << "INF\t"; // LL
        output << "INF\t"; // LL/length
        output << "INF\t" << endl; // log-odds
      }
    }
    output.close();
  }
  // Calculate Z-score
  void Operation::ComputeZ_Score(string dir) {
    ofstream result;
    string filename = dir + "/indv_result";
    result.open(filename.data(), ios::out);
    filename = dir + "/stat_result";
    ofstream statistics;
    statistics.open(filename.data(), ios::out);
    int lot_size = log_odds_table_.size();
    double mean = sum_of_logodds_ / lot_size;
    double stdev = 0;
    for (int i = 0; i < lot_size; i++) {
      stdev += pow(log_odds_table_.at(i).LogOdds - mean, 2);
    }
    stdev /= lot_size;
    stdev = sqrt(stdev);
    vector<double>z_score;
    double max = 0, subsum_z = 0;
    string src = log_odds_table_.at(0).Source;
    int count_of_src = 0;
    result << "source\tsequence\tz-score\t#" << endl;
    statistics << "source\tmean\tstdev\tmax" << endl;
    for (int i = 0; i < lot_size; i++) {
      double indv_z_score = (log_odds_table_.at(i).LogOdds - mean) / stdev;
      result << log_odds_table_.at(i).Source << "\t"; // source #
      result << log_odds_table_.at(i).Sequence << "\t"; // sequence
      result << indv_z_score << "\t"; // z_score
      if (src != log_odds_table_.at(i).Source || i == lot_size - 1) {
        double sigma = 0;
        double m = subsum_z / z_score.size();
        for (unsigned int j = 0; j < z_score.size(); j++) {
          sigma += pow(z_score.at(j) - m, 2);
        }
        sigma /= z_score.size();
        sigma = sqrt(sigma);
        statistics << src << "\t" << m << "\t" << sigma << "\t" << max << endl;
        if (i != lot_size - 1)
          count_of_src++;
        // initialization (z-score of the source)
        z_score.clear();
        z_score.push_back(indv_z_score);
        max = indv_z_score;
        subsum_z = indv_z_score;
        src = log_odds_table_.at(i).Source;
      } else {
        if (max < indv_z_score) max = indv_z_score;
        subsum_z += indv_z_score;
        z_score.push_back(indv_z_score);
      }
      result << count_of_src << "\t" << endl; // source number
    }
    result.close();
    statistics.close();
    // initialization (log-odds of the model n)
    log_odds_table_.clear();
    sum_of_logodds_ = 0;
  }
  void Operation::SetBackgroundProbabilities(void) {
    ifstream ifs;
    ifs.open("background_probabilities", ios::in);
    string nucleotide[] = {"A", "C", "G", "T"};
    string buffer;
    int i = 0;
    for (getline(ifs, buffer); !buffer.empty(); getline(ifs, buffer)) {
      background_probabilities_.insert(
        map<string, double>::value_type(nucleotide[i],
                                mycommands::GetDigit<double>(buffer))
      );
      i++;
    }
  }
};
