#ifndef INCLUDED_COMMANDS
#include "header/commands.h"
#endif // INCLUDED_COMMANDS

using namespace std;

namespace mycommands {
   int GetLineWithoutComments(ifstream *ifs, string *buff,
                              const string &mark) {
      getline(*ifs, *buff);
      while(buff->substr(0,1) == mark)
         getline(*ifs, *buff);
      return buff->length();
   }
   int GetWordWithoutComments(ifstream *ifs, string *buff,
                              const string &mark) {
      streamoff s, e;
      s = ifs->tellg();
      getline(*ifs, *buff);
      while(buff->substr(0,1) == mark) {
         s = ifs->tellg();
         getline(*ifs, *buff);
      }
      e = ifs->tellg();
      ifs->seekg((s-e), ios::cur);
      *ifs >> *buff;
      return buff->length();
   }
};
