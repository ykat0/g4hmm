// To run forward algorithm
#ifndef INCLUDED_FORWARD
#define INCLUDED_FORWARD

#ifndef INCLUDED_RECURRENCE
#include "recurrence.h"
#endif //INCLUDED_RECURRENCE

namespace myforward {
  class Forward : private myrecurrence::Recurrence {
   public:
    Forward() : Recurrence() {};
    ~Forward() {};
    double Run(const std::string &input_sequence);
    double Run(const std::string &input_sequence,
               const int &k, const int &i);
    void ShowResult();
    void Clear();
   private:
    double Recurse(const int &k, const int &i);
  };
};

#endif // INCLUDED_FORWARD
