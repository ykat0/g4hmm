#ifndef INCLUDED_COMMANDS
#define INCLUDED_COMMANDS

#ifndef _IOSTREAM_
#include <iostream>
#endif // _IOSTREAM_
#ifndef _FSTREAM_
#include <fstream>
#endif // _FSTREAM_
#ifndef _STRING_
#include <string>
#endif // _STRING_
#ifndef _SSTREAM_
#include <sstream>
#endif // _SSTREAM_

namespace mycommands {
  template <class input_Type>
  std::string GetString(const input_Type &i) { // number to string
    std::stringstream ss;
    ss << i;
    return ss.str();
  }
  template <class return_Type>
  return_Type GetDigit(const std::string &s) { // string to number
     std::stringstream ss;
     return_Type i;
     ss << s;
     ss >> i;
     return i;
  }
  // Pass comments and read a line of strings.
  int GetLineWithoutComments(std::ifstream *ifs, std::string *buff,
                             const std::string &mark);
  // Pass comments and read a string.
  int GetWordWithoutComments(std::ifstream *ifs, std::string *buff,
                             const std::string &mark);
};

#endif // INCLUDED_COMMANDS
