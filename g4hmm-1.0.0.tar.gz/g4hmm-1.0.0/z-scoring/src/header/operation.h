#ifndef INCLUDED_OPERATION
#define INCLUDED_OPERATION

#ifndef INCLUDED_HEADER
#include "header.h"
#endif //INCLUDED_HEADER
#ifndef INCLUDED_HMM
#include "hmm.h"
#endif // INCLUDED_HMM
#ifndef INCLUDED_FORWARD
#include "forward.h"
#endif // INCLUDED_FORWARD
#include <sys/stat.h>
#include <sys/types.h>


namespace myoperation {
  struct LogOddsTable {
    LogOddsTable(std::string v1, std::string v2, double v4) :
      Source(v1),
      Sequence(v2),
      LogOdds(v4) {};
    std::string Source;
    std::string Sequence;
    double LogOdds;
  };
  class Operation {
   public:
	   Operation() : sum_of_logodds_(0) {};
     int SetHMM(const std::string &define_filename);
     int SetSequence(const std::string &source_filename);
     void SetBackgroundProbabilities(void);
     double CalculateLogOdds(double probability, std::string sequence);
     void MakeLogOddsTable(std::string dir, std::string src);
     void ComputeZ_Score(std::string dir);
   private:
     std::map<std::string, double> background_probabilities_;
     std::ifstream hmm_file_;
     std::vector<std::string> sequence_set_;
     std::vector<LogOddsTable> log_odds_table_;
     double sum_of_logodds_;
     myhmm::HMM hmm_;
     myforward::Forward fo_;
  };
};

#endif
