#ifndef INCLUDED_RECURRENCE
#define INCLUDED_RECURRENCE

#ifndef INCLUDED_HEADER
#include "header.h"
#endif //INCLUDED_HEADER
#ifndef INCLUDED_HMM
#include "hmm.h"
#endif // INCLUDED_HMM

namespace myrecurrence {
  class Recurrence : public myhmm::HMM {
   public:
    Recurrence() : result_flag_(false) {};
    virtual ~Recurrence() {};
    class DPCell {
     public:
      double p; // Probability of arriving the state
      int k; // state
      int i; // alphabet
      int l; // previout state
      DPCell(double pp, int kk, int ii, int ll); // constractor
      void ShowVariable();
    };

    virtual double Recurse(const int &k, const int &i) { return 0; };
    virtual double Run(const std::string &input_sequence) { return 0; };
    virtual double Run(const std::string &input_sequence,
                       const int &k, const int &i) { return 0; };
    virtual void ShowResult() {};
    // Subroutine
    template <class return_Type>
    return_Type IsOutput(const int &i,
                         const return_Type &yes,
                         const return_Type &no);
    // Dynamic programming table
    std::vector<DPCell> dptable_; // DP-table
    int ReferDPTable(const int &k, const int &i);
    
    const std::string *target_;
    bool result_flag_;
  };
  // Template
  template <class return_Type>
  return_Type Recurrence::IsOutput(const int &i,
                       const return_Type &yes,
                       const return_Type &no) {
    if ((unsigned)i < target_->length()) {
      return yes;
    } else {
      return no;
    }
  }
};

#endif // INCLUDED_VITERBI
