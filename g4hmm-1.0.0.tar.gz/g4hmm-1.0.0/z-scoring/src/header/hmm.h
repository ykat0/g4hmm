// Get / Use Hidden Markov Model from text-file written definition of HMM.
#ifndef INCLUDED_HMM
#define INCLUDED_HMM

#ifndef INCLUDED_HEADER
#include "header.h"
#endif //INCLUDED_HEADER

namespace myhmm {
  enum TypeOfState { begin, end, output };
  enum Alphabet {A, C, G, T, alphabet_size};
  // (Q, Pt, Po)
  struct Elements {
    std::vector<TypeOfState> state;
    std::vector<double> transition_probability;
    std::vector<double> output_probability;
  };
  class HMM {
   public:
    HMM() {};
    ~HMM() {};
    void Setup(std::ifstream *hmm_source);
    int GetAlphabetSize();
    int GetIdOfAlphabet(const std::string &alphabet);
    int GetNumberOfState();
    bool IsTypeOfState(const unsigned int &state, const TypeOfState &buf);
    bool IsTypeOfState(const unsigned int &state,
                       const TypeOfState &buf1, const TypeOfState &buf2);
    double GetTransitionProbability(const unsigned int &source,
                                    const unsigned int &distance);
    double GetOutputProbability(const unsigned int &state,
                                const int &alphabet);
    int SetTransitionProbability(const std::vector<double> &set);
    int SetOutputProbability(const std::vector<double> &set);
    int WriteHMMSpec(const std::string &output_file);
    bool IsElement();
   private:
    static Elements elements_;
    void SetupState(const int &state_number);
    void SetupTerminalProbability(const TypeOfState &mode);
  };
};

#endif // INCLUDED_HMM
