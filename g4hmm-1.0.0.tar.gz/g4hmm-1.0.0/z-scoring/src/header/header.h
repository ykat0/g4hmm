#ifndef INCLUDED_HEADER
#define INCLUDED_HEADER

#ifndef _IOSTREAM_
#include <iostream>
#endif // _IOSTREAM_
#ifndef _CMATH_
#include <cmath>
#endif // _CMATH_
#ifndef _FSTREAM_
#include <fstream>
#endif // _FSTREAM_
#ifndef _STRING_
#include <string>
#endif // _STRING_
#ifndef _SSTREAM_
#include <sstream>
#endif // _SSTREAM_
#ifndef _VECTOR_
#include <vector>
#endif // _VECTOR_
#ifndef _IOMANIP_
#include <iomanip>
#endif // _IOMANIP_
#ifndef _MAP_
#include <map>
#endif // _MAP_

#ifndef INCLUDED_COMMANDS
#include "commands.h"
#endif // INCLUDED_COMMANDS

const double INF = 1e+300;

#endif // INCLUDED_HEADER
