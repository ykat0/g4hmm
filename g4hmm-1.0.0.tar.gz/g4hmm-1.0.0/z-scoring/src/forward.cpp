#ifndef INCLUDED_FORWARD
#include "header/forward.h"
#endif // INCLUDED_FORWARD

using namespace std;
using namespace myhmm;
using namespace myrecurrence;

namespace myforward {
  //// class Forward
  double Forward::Recurse(const int &k, const int &i) {
    // Terminal condition 1
    if (IsTypeOfState(k, begin)) {
      double p_sum = IsOutput(i, 0.0, 1.0);
      dptable_.push_back(DPCell(p_sum, k, i, 0));
      return p_sum;
    } else {
      double p_sum = 0, output_probability;
      // Terminal condition 2 (finish to read)
      if (IsOutput(i, true, false)) { // not finish
        output_probability =
          GetOutputProbability(k, GetIdOfAlphabet(target_->substr(i, 1)));
      } else { // finish
        output_probability = (IsTypeOfState(k, end) ? 1.0 : 0.0);
      }
      if (output_probability > 0.0) {
        int refer_cell;
        for (int l = 0; l < GetNumberOfState(); l++) {
          if (GetTransitionProbability(l, k) > 0.0) {
            refer_cell = ReferDPTable(l, i - 1);
            p_sum += GetTransitionProbability(l, k) *
                      ((unsigned)refer_cell < dptable_.size() ?
                      dptable_[refer_cell].p :
                      Recurse(l, i - 1));
          } // else p_sum += 0;
        }
        p_sum *= output_probability;
      } else {
        p_sum = 0;
      }
      dptable_.push_back(DPCell(p_sum, k, i, 0));
      return p_sum;
    }
  }
  double Forward::Run(const string &input_sequence) {
    return Run(input_sequence,
               GetNumberOfState() - 1,
               input_sequence.length());
  }
  double Forward::Run(const string &input_sequence,
                      const int &k, const int &i) {
    result_flag_ = false;
    dptable_.clear();
    target_ = &input_sequence;
    if (IsTypeOfState(k, begin)) {
      return 1.0;
    } else {
      result_flag_ = true;
      return Recurse(k, i);
    }
  }
  void Forward::ShowResult() {
    cout << " RESULT:" << endl;
    if(!result_flag_) {
      cout << "  NO DATA. You MUST do run() first." << endl;
    } else {
      cout << "  DP-table size: " << dptable_.size() << endl;
    }
  }
  void Forward::Clear() {
    result_flag_ = false;
    dptable_.clear();
  }
};
