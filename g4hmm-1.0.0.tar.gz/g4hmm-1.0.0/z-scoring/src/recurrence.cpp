#ifndef INCLUDED_RECURRENCE
#include "header/recurrence.h"
#endif // INCLUDED_RECURRENCE

using namespace std;

namespace myrecurrence {
  //// class Recurrence::DPCell
  Recurrence::DPCell::DPCell(double pp, int kk, int ii, int ll) {
    p = pp;
    k = kk;
    i = ii;
    l = ll;
  }
  void Recurrence::DPCell::ShowVariable() {
    cout << "  (P=" << p << ",K=" << k << ",I=" << i << ",L=" << l << ")";
  }
  //// class Recurrence
  int Recurrence::ReferDPTable(const int &k, const int &i) {
    for (unsigned int loop = 0; loop < dptable_.size(); loop++) {
      if (dptable_[loop].k == k && dptable_[loop].i == i)
        return loop;
    }
    return -1;
  }
};
