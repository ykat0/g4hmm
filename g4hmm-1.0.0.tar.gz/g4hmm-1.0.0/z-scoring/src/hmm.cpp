#ifndef INCLUDED_HMM
#include "header/hmm.h"
#endif // INCLUDED_HMM

using namespace std;
using namespace mycommands;

namespace myhmm {
  Elements HMM::elements_;
  //// class HMM
  // Setup
  void HMM::Setup(ifstream *hmm_source) {
    if (IsElement()) {
      elements_.state.clear();
      elements_.transition_probability.clear();
      elements_.output_probability.clear();
    }
    string buff;
    // State
    GetLineWithoutComments(hmm_source, &buff, "#");
    SetupState(GetDigit<int>(buff));
    // Probabilities
    //SetupTerminalProbability(begin);
    while (!buff.empty()) {
      // Transition
      GetWordWithoutComments(hmm_source, &buff, "#");
      for (unsigned int i = 0; i < elements_.state.size(); i++) {
        if (i == GetDigit<unsigned int>(buff)) {
          GetWordWithoutComments(hmm_source, &buff, "#");
          elements_.transition_probability.push_back(GetDigit<double>(buff));
          GetWordWithoutComments(hmm_source, &buff, "#");
        } else {
          elements_.transition_probability.push_back(0);
        }
      }
      // Output
      for (int i = 0; i < 4; i++) {
        GetWordWithoutComments(hmm_source, &buff, "#");
        elements_.output_probability.push_back(GetDigit<double>(buff));
      }
      // Avoid comments
      streamoff s, e;
      s = hmm_source->tellg();
      GetWordWithoutComments(hmm_source, &buff, "#");
      e = hmm_source->tellg();
      hmm_source->seekg((s-e), ios::cur);
    }
    SetupTerminalProbability(end);
  }
  void HMM::SetupState(const int &state_number) {
    elements_.state.push_back(begin);
    for(int i = 0; i < state_number; i++) {
      elements_.state.push_back(output);
    }
    elements_.state.push_back(end);
  }
  void HMM::SetupTerminalProbability(const TypeOfState &mode) {
    int head = 0;
    if (mode == begin)
      head = 1;
    elements_.transition_probability.push_back(0);
    elements_.transition_probability.push_back(head);
    for (unsigned int i = 2; i < elements_.state.size(); i++)
      elements_.transition_probability.push_back(0);
    for (int i = 0; i < alphabet_size; i++)
      elements_.output_probability.push_back(0);
  }
  // Regarding Alphabet
  int HMM::GetAlphabetSize() {
    return alphabet_size;
  }
  int HMM::GetIdOfAlphabet(const string &alphabet) {
    map<string, Alphabet> return_id;
    return_id.insert(make_pair("A", A));
    return_id.insert(make_pair("C", C));
    return_id.insert(make_pair("G", G));
    return_id.insert(make_pair("T", T));
    map<string, Alphabet>::iterator finder = return_id.find(alphabet);
    if (finder != return_id.end()) {
      return finder->second;
    } else {
      return -1;
    }
  }
  int HMM::GetNumberOfState() {
    return elements_.state.size();
  }
  // IF THIS STATE IS XXX?
  bool HMM::IsTypeOfState(const unsigned int &state, const TypeOfState &buf) {
    if (IsElement()) {
      if (elements_.state[state] == buf)
        return true;
      else
        return false;
    } else {
      return false;
    }
  }
  bool HMM::IsTypeOfState(const unsigned int &state, 
                          const TypeOfState &buf1, const TypeOfState &buf2) {
    if (IsElement()) {
      if (elements_.state[state] == buf1 || elements_.state[state] == buf2)
        return true;
      else
        return false;
    } else {
      return false;
    }
  }
  // Get Probabilities
  double HMM::GetTransitionProbability(
      const unsigned int &source,
      const unsigned int &distance) {
    if (IsElement()) {
      if (source < elements_.state.size() &&
          distance < elements_.state.size() &&
          source >= 0 && distance >= 0) {
        int position = source * elements_.state.size() + distance;
        return elements_.transition_probability[position];
      } else {
        return 0;
      }
    } else {
      return -1;
    }
  }
  double HMM::GetOutputProbability(
      const unsigned int &state,
      const int &alphabet) {
    if (IsElement()) {
      if (state < elements_.state.size() &&
          alphabet < alphabet_size && alphabet >= 0) {
        int position = state * alphabet_size + alphabet;
        return elements_.output_probability[position];
      } else {
        return 0;
      }
    } else {
      return -1;
    }
  }
  // Set Probabilities
  int HMM::SetTransitionProbability(const vector<double> &set) {
    cout << "Set transition prob." << endl;
    elements_.transition_probability.clear();
    elements_.transition_probability.reserve(set.size());
    copy(set.begin(), set.end(),
         back_inserter(elements_.transition_probability));
    return elements_.transition_probability.size();
  }
  int HMM::SetOutputProbability(const vector<double> &set) {
    cout << "Set output prob." << endl;
    elements_.output_probability.clear();
    elements_.output_probability.reserve(set.size());
    copy(set.begin(), set.end(),
         back_inserter(elements_.output_probability));
    return elements_.output_probability.size();
  }
  // For Save Renewed HMM Specification
  int HMM::WriteHMMSpec(const string &output_file) {
    int state_size = elements_.state.size();
    ofstream ofs;
    ofs.open(output_file.data(), ios::out);
    ofs << "#State" << endl;
    ofs << (elements_.state.size() - 2) << endl;
    ofs << "#Prob." << endl;
    bool saved_flag;
    for (int i = 0; i < state_size - 1; i++) {
      saved_flag = false;
      for (int j = 0; j < state_size; j++) {
        if (elements_.transition_probability.at(i * state_size + j) > 0) {
          saved_flag = true;
          ofs << j << " ";
          ofs << elements_.transition_probability.at(i * state_size + j) << " ";
        }
      }
      if (!saved_flag) {
        ofs << state_size - 1 << " " << 1 << " ";
      }
      ofs << ":";
      for (int k = 0; k < alphabet_size; k++)
        ofs << " " << elements_.output_probability.at(i * alphabet_size + k);
      ofs << endl;
    }
    ofs.close();
    return 0;
  }
  // IF THERE ARE SOME ELEMENTS
  //   return TRUE
  // ELSE
  //   return FALSE
  bool HMM::IsElement() {
    double flag =
      elements_.state.size() *
      elements_.transition_probability.size() *
      elements_.output_probability.size();
    if(flag > 0)
      return true;
    else
      return false;
  }
};
