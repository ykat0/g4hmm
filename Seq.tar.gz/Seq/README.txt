"g4train.txt" is used to train the parameters of a specified HMM.
"g4validate.txt" is actually one file that integrates "g4positive.txt" and "g4negative.txt."
